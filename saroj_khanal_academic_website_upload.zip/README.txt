SAROJ KHANAL ACADEMIC WEBSITE

1. Upload index.html to the TOP LEVEL (root) of:
   https://github.com/hamiduimatra-jpg/saroj-khanal-research

2. On GitHub, open Settings > Pages.
3. Under Build and deployment, choose:
   Source: Deploy from a branch
   Branch: main
   Folder: /(root)
4. Click Save. Wait for deployment, then visit:
   https://hamiduimatra-jpg.github.io/saroj-khanal-research/

IMPORTANT:
- Check every publication title, author order, year and DOI before public launch.
- This page contains no private email address.
- Do not upload private documents or sensitive personal information.
